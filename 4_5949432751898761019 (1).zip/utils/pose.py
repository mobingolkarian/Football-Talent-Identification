"""
Pose analysis utilities for football videos using MediaPipe.
Samples frames for speed and extracts simple technique indicators.
"""
from __future__ import annotations
import cv2
import numpy as np

def _angle(a, b, c) -> float:
    """Angle (degrees) at point b formed by a-b-c."""
    a = np.array(a); b = np.array(b); c = np.array(c)
    ba = a - b
    bc = c - b
    denom = (np.linalg.norm(ba) * np.linalg.norm(bc) + 1e-9)
    cosang = np.clip(np.dot(ba, bc) / denom, -1.0, 1.0)
    return float(np.degrees(np.arccos(cosang)))

def analyze_video(video_path: str, max_frames: int = 200, sample_every: int = 3, draw: bool = True):
    """
    Returns (output_path, summary_dict).
    Summary includes mean knee angle, mean hip angle, stability score and frames analyzed.
    """
    import mediapipe as mp

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError("Cannot open video. Please upload a valid video file.")

    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 360)

    out_path = None
    writer = None
    if draw:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        out_path = video_path.rsplit(".", 1)[0] + "_pose.mp4"
        writer = cv2.VideoWriter(out_path, fourcc, fps, (w, h))

    mp_pose = mp.solutions.pose
    mp_draw = mp.solutions.drawing_utils

    knee_angles, hip_angles, center_shifts = [], [], []

    with mp_pose.Pose(static_image_mode=False, model_complexity=1, enable_segmentation=False) as pose:
        frame_idx, used = 0, 0
        prev_center = None

        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame_idx += 1
            if frame_idx % sample_every != 0:
                continue

            used += 1
            if used > max_frames:
                break

            img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            res = pose.process(img)

            if res.pose_landmarks:
                lm = res.pose_landmarks.landmark

                def p(idx):
                    return (lm[idx].x * w, lm[idx].y * h)

                # Right hip/knee/ankle: 24/26/28; Left: 23/25/27; shoulders: 12/11
                r_vis = lm[24].visibility + lm[26].visibility + lm[28].visibility
                if r_vis >= 1.5:
                    hip, knee, ankle = p(24), p(26), p(28)
                    shoulder = p(12)
                else:
                    hip, knee, ankle = p(23), p(25), p(27)
                    shoulder = p(11)

                knee_ang = _angle(hip, knee, ankle)
                hip_ang = _angle(shoulder, hip, knee)
                knee_angles.append(knee_ang)
                hip_angles.append(hip_ang)

                center = np.array([hip[0], hip[1]], dtype=float)
                if prev_center is not None:
                    center_shifts.append(float(np.linalg.norm(center - prev_center)))
                prev_center = center

                if draw:
                    mp_draw.draw_landmarks(frame, res.pose_landmarks, mp_pose.POSE_CONNECTIONS)
                    cv2.putText(frame, f"Knee: {knee_ang:.1f}", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
                    cv2.putText(frame, f"Hip: {hip_ang:.1f}", (10, 60),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

            if draw and writer is not None:
                writer.write(frame)

    cap.release()
    if writer is not None:
        writer.release()

    knee_mean = float(np.mean(knee_angles)) if knee_angles else None
    hip_mean = float(np.mean(hip_angles)) if hip_angles else None
    shift_mean = float(np.mean(center_shifts)) if center_shifts else None
    stability = None if shift_mean is None else max(0.0, min(100.0, 100.0 - shift_mean * 5.0))

    return out_path, {
        "knee_angle_mean": knee_mean,
        "hip_angle_mean": hip_mean,
        "stability_score": stability,
        "frames_analyzed": used
    }
