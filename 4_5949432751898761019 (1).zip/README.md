# Football Talent Identification Project

This repository contains the final project for a football talent identification and match prediction system.

## Project Description
The system analyzes player information and movement data to:
- Identify talent level suitability for football
- Analyze movement quality using pose estimation from video
- Predict match outcomes

## Included Files
- Project report (PDF)
- Project package (code and resources)
- Iran-oriented datasets (athletes + matches)

## Technologies
- Python
- Data Analysis
- Computer Vision (Pose Estimation)
- Machine Learning

## Run (Local)
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Author
Mobin Golkarian (مبین گلکاریان)
