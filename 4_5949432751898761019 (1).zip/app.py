import streamlit as st
import pandas as pd
import joblib
import json
import tempfile
from pathlib import Path

st.set_page_config(page_title="Football Talent Identification", layout="wide")

BASE = Path(__file__).parent
DATA = BASE / "data"
MODELS = BASE / "models"

@st.cache_resource
def load_models():
    talent = joblib.load(MODELS / "talent_model.pkl")
    match = joblib.load(MODELS / "match_model.pkl")
    with open(MODELS / "metrics.json", "r", encoding="utf-8") as f:
        metrics = json.load(f)
    return talent, match, metrics

talent_model, match_model, metrics = load_models()

st.title("Football Talent Identification & Match Outcome Prediction")
st.caption("Author: Mobin Golkarian (مبین گلکاریان)")

tab1, tab2, tab3, tab4 = st.tabs(["1) Text Talent ID", "2) Pose (Video)", "3) Match Prediction", "Datasets / Info"])

with tab1:
    st.subheader("Stage 1 — Text-based talent identification")
    c1, c2, c3 = st.columns(3)
    with c1:
        age = st.number_input("Age", 10, 40, 18)
        height = st.number_input("Height (cm)", 130, 210, 175)
        weight = st.number_input("Weight (kg)", 35, 130, 70)
        exp = st.number_input("Experience (years)", 0.0, 20.0, 4.0, step=0.5)
    with c2:
        sprint = st.number_input("30m Sprint (sec)", 3.0, 7.0, 4.4, step=0.01)
        vo2 = st.number_input("VO2max", 20.0, 80.0, 48.0, step=0.1)
        agility = st.number_input("Agility T-test (sec)", 6.0, 16.0, 9.8, step=0.01)
    with c3:
        shot = st.number_input("Shot power (0-100)", 0.0, 100.0, 72.0, step=0.1)
        passing = st.number_input("Passing score (0-100)", 0.0, 100.0, 70.0, step=0.1)
        stamina = st.number_input("Stamina score (0-100)", 0.0, 100.0, 75.0, step=0.1)

    position = st.selectbox("Current position", ["Goalkeeper","Defender","Midfielder","Forward"])
    foot = st.selectbox("Dominant foot", ["Right","Left"])
    province = st.selectbox("Province", ["Tehran","Isfahan","Fars","Khorasan Razavi","East Azerbaijan","Khuzestan","Kerman","Mazandaran","Gilan","Qom","Yazd","Alborz"])

    if st.button("Predict talent level"):
        X = pd.DataFrame([{
            "age": age, "height_cm": height, "weight_kg": weight, "experience_years": exp,
            "sprint_30m_sec": sprint, "vo2max": vo2, "agility_ttest_sec": agility,
            "shot_power": shot, "passing_score": passing, "stamina_score": stamina,
            "position": position, "dominant_foot": foot, "province": province
        }])
        pred = talent_model.predict(X)[0]
        proba = talent_model.predict_proba(X)[0]
        classes = list(talent_model.named_steps["clf"].classes_)
        st.success(f"Predicted level: **{pred}**")
        st.json({cls: float(p) for cls, p in zip(classes, proba)})

with tab2:
    st.subheader("Stage 2 — Pose analysis from video (MediaPipe)")
    st.write("Upload a short football clip (running, shooting, change of direction). Frames are sampled for speed.")
    uploaded = st.file_uploader("Upload video (mp4/mov)", type=["mp4","mov","m4v"])
    max_frames = st.slider("Max frames to analyze", 50, 500, 200, step=10)
    sample_every = st.slider("Sample every N frames", 1, 10, 3)

    if uploaded is not None:
        from utils.pose import analyze_video
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp:
            tmp.write(uploaded.read())
            tmp_path = tmp.name

        with st.spinner("Analyzing video..."):
            out_path, summary = analyze_video(tmp_path, max_frames=max_frames, sample_every=sample_every, draw=True)

        st.success("Done! Pose overlay generated.")
        if out_path:
            st.video(out_path)
        st.json(summary)

with tab3:
    st.subheader("Stage 3 — Match outcome prediction")
    c1, c2 = st.columns(2)
    with c1:
        home = st.selectbox("Home team", ["Esteghlal","Persepolis","Sepahan","Tractor","Foolad","Gol Gohar","Zob Ahan","Nassaji","Shams Azar","Paykan","Malavan","Mes Kerman"])
        away = st.selectbox("Away team", ["Persepolis","Esteghlal","Sepahan","Tractor","Foolad","Gol Gohar","Zob Ahan","Nassaji","Shams Azar","Paykan","Malavan","Mes Kerman"])
    with c2:
        home_rating = st.slider("Home rating", 40.0, 95.0, 75.0, step=0.5)
        away_rating = st.slider("Away rating", 40.0, 95.0, 73.0, step=0.5)

    home_form = st.slider("Home form (-1..1)", -1.0, 1.0, 0.2, step=0.05)
    away_form = st.slider("Away form (-1..1)", -1.0, 1.0, -0.1, step=0.05)
    home_xg = st.slider("Home xG", 0.1, 3.5, 1.4, step=0.05)
    away_xg = st.slider("Away xG", 0.1, 3.5, 1.1, step=0.05)

    if home == away:
        st.warning("Home and Away teams must be different.")
    elif st.button("Predict match result"):
        X = pd.DataFrame([{
            "home_team": home, "away_team": away,
            "home_rating": home_rating, "away_rating": away_rating,
            "home_form": home_form, "away_form": away_form,
            "home_xg": home_xg, "away_xg": away_xg
        }])
        pred = match_model.predict(X)[0]
        proba = match_model.predict_proba(X)[0]
        classes = list(match_model.named_steps["clf"].classes_)
        st.success(f"Predicted result: **{pred}**")
        st.json({cls: float(p) for cls, p in zip(classes, proba)})

with tab4:
    st.subheader("Datasets / Notes")
    st.write("Iran-oriented synthetic datasets (province/club/team naming). Replace later with real measurements.")
    st.json(metrics)
    st.markdown("- `data/athletes_iran_football.csv`")
    st.markdown("- `data/matches_iran_football.csv`")
    if st.checkbox("Preview athlete dataset"):
        st.dataframe(pd.read_csv(DATA / "athletes_iran_football.csv").head(20))
    if st.checkbox("Preview match dataset"):
        st.dataframe(pd.read_csv(DATA / "matches_iran_football.csv").head(20))
