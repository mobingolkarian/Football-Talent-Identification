import json
from pathlib import Path
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier

BASE = Path(__file__).parent
DATA = BASE / "data"
MODELS = BASE / "models"

def train():
    athletes = pd.read_csv(DATA / "athletes_iran_football.csv")
    X = athletes[["age","height_cm","weight_kg","experience_years","sprint_30m_sec","vo2max","agility_ttest_sec","shot_power","passing_score","stamina_score","position","dominant_foot","province"]]
    y = athletes["talent_level"]

    cat_cols = ["position","dominant_foot","province"]
    num_cols = [c for c in X.columns if c not in cat_cols]

    pre = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
                             ("num", "passthrough", num_cols)])
    clf = RandomForestClassifier(n_estimators=250, random_state=42, n_jobs=-1)
    pipe = Pipeline([("pre", pre), ("clf", clf)])
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    pipe.fit(Xtr, ytr)
    acc = accuracy_score(yte, pipe.predict(Xte))
    joblib.dump(pipe, MODELS / "talent_model.pkl")

    matches = pd.read_csv(DATA / "matches_iran_football.csv")
    Xm = matches[["home_team","away_team","home_rating","away_rating","home_form","away_form","home_xg","away_xg"]]
    ym = matches["result"]
    catm = ["home_team","away_team"]
    numm = [c for c in Xm.columns if c not in catm]

    pre_m = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), catm),
                               ("num", "passthrough", numm)])
    clf_m = RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1)
    pipe_m = Pipeline([("pre", pre_m), ("clf", clf_m)])
    Xmtr, Xmte, ymtr, ymte = train_test_split(Xm, ym, test_size=0.2, random_state=42, stratify=ym)
    pipe_m.fit(Xmtr, ymtr)
    acc_m = accuracy_score(ymte, pipe_m.predict(Xmte))
    joblib.dump(pipe_m, MODELS / "match_model.pkl")

    metrics = {"talent_model_accuracy_demo": round(float(acc),3),
               "match_model_accuracy_demo": round(float(acc_m),3),
               "notes": "Demo metrics on synthetic Iran-oriented datasets."}
    with open(MODELS / "metrics.json","w",encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    print(metrics)

if __name__ == "__main__":
    train()
